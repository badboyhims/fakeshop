import React,{useEffect,useState} from 'react'





// importing components 
import ProductCard from '../components/ProductCard';
import Loading from '../components/Loading';


import '../styles/home.css'





const Home = () => {
    const [productsArray, setProductsArray] = useState([])
    const fetchDetails  = async ()=>{
        const res = await fetch('https://fakestoreapi.com/products',{
            method:"GET",
            headers:{
                Accept:"application/json",
                "content-Type":"application/json"
            },
            Credential:'include'
        });
       const data = await res.json();
       setProductsArray(data);
    }

    useEffect(() => {
        fetchDetails();
    }, [])
    
    
    return (
        <div id='home'>
            <div className="container-fluid pt-2 pb-5">

                <div className='d-flex flex-wrap  align-items-center'>
                    {productsArray.length==0
                    ?<Loading />
                    :productsArray.map((product,ind)=>(
                        <ProductCard key={ind} product={product} />
                    ))
                    }
                </div>
            </div>
        </div>
    )
}

export default Home